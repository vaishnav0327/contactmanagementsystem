import { Component, OnInit } from '@angular/core';
import { Contact } from '../contact.model';
import { ActivatedRoute, Router } from '@angular/router';

import { ContactService } from '../contact.service';

@Component({
  selector: 'app-edit-contact',
  standalone: false,
  
  templateUrl: './edit-contact.component.html',
  styleUrl: './edit-contact.component.css'
})
export class EditContactComponent  implements OnInit {
  contactId!: number;
  contact:  Contact = {
    contactId: 0,
    contactName: '',
    emailId: '',
    contactpassword: '',
    phone: '',
    address: '',
  
  };

  constructor(
    private route: ActivatedRoute,
    private contactService: ContactService,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Get the employee ID from the route
    this.contactId = +this.route.snapshot.paramMap.get('id')!;
    this.loadContactDetails();
  }

  // Fetch employee details by ID
  loadContactDetails(): void {
    this.contactService.getContactById(this.contactId).subscribe(
      (data) => {
        this.contact = data;
      },
      (error) => {
        console.error('Error fetching contact:', error);
      }
    );
  }

  // Save updated employee data
  saveChanges(): void {
    this. contactService.updateContact(this. contactId, this. contact).subscribe(
      () => {
        alert('Contact updated successfully!');
        this.router.navigate(['/viewCon']); // Navigate back to the list view
      },
      (error) => {
        console.error('Error updating Contact:', error);
      }
    );
  }
  deleteContact(): void {
    const confirmDelete = confirm('Are you sure you want to delete this event?');
    if (confirmDelete) {
      this.contactService.deleteContact(this.contactId).subscribe(
        () => {
          alert('Contact deleted successfully!');
          this.router.navigate(['/viewEmp']);
        },
        (error) => {
          console.error('Error deleting contact:', error);
          alert('Failed to delete the contact.');
        }
      );
    }
  }

  goBack(): void {
    this.router.navigate(['/']); // Navigate to the employee list
  }

}


