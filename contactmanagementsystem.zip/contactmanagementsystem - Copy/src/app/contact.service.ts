import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Contact } from './contact.model';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  editContact(contactId: number) {
    throw new Error('Method not implemented.');
  }

  private api = 'http://localhost:8080'; // Your backend URL
  addContact: any;

  constructor(private http: HttpClient) { }

  saveContact( contactData: any): Observable<any> {
    return this.http.post(`${this.api}/save/contact`, contactData);
  }
  
  // Fetch  contact by ID
  getContactById( contactId: number): Observable<any> {
    return this.http.get(`${this.api}/get/contact/${ contactId}`);
  }


  // Method to fetch  contacts
  getContacts(): Observable<Contact[]> {
    return this.http.get<Contact[]>(`${this.api}/get/contact`);
  }
  // Delete an  contact
  deleteContact( contactId: number): Observable<void> {
    return this.http.delete<void>(`${this.api}/delete/contact/${ contactId}`);
  }
  // Update an  contact
  updateContact(contactId: number, contact: Contact): Observable<Contact> {
    return this.http.put<Contact>(`${this.api}/update/contact`, contact);
  }
  // Register a user
  registerContact(contact: any): Observable<any> {
    return this.http.post<any>(`${this.api}/register`, contact); // POST request to register the user
  }
  
}
