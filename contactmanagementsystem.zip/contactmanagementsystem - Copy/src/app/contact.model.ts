export interface Contact {

  contactId: any;
  contactName: any;
  emailId: any;
  contactpassword: any;
  phone: any;  // Uppercase 'C'
  address: any;       // Uppercase 'A'
}

  