import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';
import { ContactService } from '../contact.service';

@Component({
  selector: 'app-register',
  standalone: false,
  
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {
  user = {
    name: '',
    email: '',
    password: ''
  };
  contact: any;
isRegistered: any;
errorMessage: any;

  constructor(private contactService: ContactService, private router: Router) {}

  // Form submit handler
  onSubmit() {
    this.contactService.registerContact(this.contact).subscribe({
      next: (response) => {
        console.log('User registered successfully', response);
        // Assuming you redirect after successful registration
        this.router.navigate(['/login']); 
      },
      error: (err) => {
        console.error('Error registering user:', err);
      }
    });
  }


 
}
