import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Contact } from '../contact.model';
import { ContactService } from '../contact.service';


@Component({
  selector: 'app-view-contact',
  standalone: false,
  
  templateUrl: './view-contact.component.html',
  styleUrl: './view-contact.component.css'
})
export class ViewContactComponent implements OnInit {
  contacts: any[] = [];
  router: any;

  constructor(private contactService: ContactService) {}

  ngOnInit() {
    this.loadContacts();
  }

  // Load contacts on initialization
  loadContacts() {
    this.contactService.getContacts().subscribe({
      next: (response) => {
        this.contacts = response;  // Assuming response is an array of contacts
      },
      error: (error) => {
        console.error('Error fetching contacts:', error);
      }
    });
  }

  // Method for editing a contact
 editContact(contactId: number): void {
    if (!contactId) {
      console.error('Invalid contact ID');
      return;
    }
    this.router.navigate(['/edit-con', contactId]);
  }
    
  // Method for deleting a contact
  deleteContact(contactId: number) {
    this.contactService.deleteContact(contactId).subscribe({
      next: () => {
        console.log('Contact deleted');
        this.loadContacts(); // Refresh the list of contacts after deletion
      },
      error: (error) => {
        console.error('Error deleting contact:', error);
      }
    });
  }
}