import { Component } from '@angular/core';
import Swal from 'sweetalert2';
import { NgForm } from '@angular/forms';
import { ContactService } from '../contact.service';
import { Contact } from '../contact.model';

@Component({
  selector: 'app-add-contact',
  standalone: false,
  
  templateUrl: './add-contact.component.html',
  styleUrl: './add-contact.component.css'
})
export class AddContactComponent {
contactId: any;
  contactName: any;
  emailId: any;
  contactpassword: any;
  phone: any;
  address: any;

constructor(private contactService: ContactService) { }


// Method to handle form submission
onSubmit() {
  let formdata={
    "contactId":this.contactId,
    "contactName":this.contactName,
    "emailId":this.emailId,
    "Password":this.contactpassword,
    "phone":this.phone, // Uppercase 'C'
    "address":this.address,
  }
    this.contactService.saveContact(this.contact).subscribe(
      

        (response:any) => {
          console.log('Contact saved successfully:', response);
               //Display a success popup
          Swal.fire({
            title: 'Success!',
            text: 'Contact saved successfully.',
            icon: 'success',
            confirmButtonText: 'OK'
          });
          
        },
        (error:any) => {
           console.error('Error saving contact:', error);
                    // Display an error popup
                    Swal.fire({
                      title: 'Error!',
                      text: 'There was a problem saving the contact. Please try again later.',
                      icon: 'error',
                      confirmButtonText: 'OK'
                    });
          
        }
      );
}
  contact(contact: any) {
    throw new Error('Method not implemented.');
  }
}
