import { Component } from '@angular/core';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  standalone: false,
  
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  
    loginData = {
      email: '',
      password: ''
    };
  
    constructor(private router: Router) {}
  
    onSubmit(): void {
      // Dummy authentication logic for demonstration
      if (this.loginData.email === 'vaishnavi@e.com' && this.loginData.password === '123456789') {
        alert('Login successful!');
        this.router.navigate(['/home']);
  
      
      } else {
        alert('Invalid credentials. Please try again.');
      }
    }
  }
  