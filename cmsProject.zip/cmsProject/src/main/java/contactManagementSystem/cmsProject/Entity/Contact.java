package contactManagementSystem.cmsProject.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "contact_management_system")
public class Contact
{
	
	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Integer contactId;
	 
	    @NotEmpty
		@Size(min = 3, message="firstName must contain atleast 3 characters") 
		private String contactName;

	    @Column(name="email_id",unique=true,length=30)
		@NotEmpty
		@Email(message="Email  is not valid!")
		public String emailId;
	    
	    @NotEmpty
		@Size(min=10, max=10, message="phoneNumber must contain 10 digits") 
		private String phone;
	    
	    @NotEmpty
		@Size(min = 8, message="Password length must be 8 and contain uppercase, lowercase, digits")
		@Pattern(regexp="(?.\\d) (?.[a-z]) (?.[A-Z]).{8,}") 
		private String contactPassword;
		
		@NotEmpty (message="Address cannot be empty")
		private String contactAddress;

		public Integer getContactId()
		{
			return contactId;
		}

		public void setContactId(Integer contactId) 
		{
			this.contactId = contactId;
		}

		public String getContactname()
		{
			return contactName;
		}

		public void setContactname(String contactname) 
		{
			this.contactName = contactname;
		}

		public String getEmailId()
		{
			return emailId;
		}

		public void setEmailId(String emailId)
		{
			this.emailId = emailId;
		}

		public String getPhone()
		{
			return phone;
		}

		public void setPhone(String phone) 
		{
			this.phone = phone;
		}

		public String getContactpassword() 
		{
			return contactPassword;
		}

		public void setContactpassword(String contactpassword)
		{
			this.contactPassword = contactpassword;
		}

		public String getContactaddress() 
		{
			return contactAddress;
		}

		public void setContactaddress(String contactaddress) 
		{
			this.contactAddress = contactaddress;
		}

		

		@Override
		public String toString() {
			return "Contact [contactId=" + contactId + ", contactname=" + contactName + ", emailId=" + emailId
					+ ", phone=" + phone + ", contactpassword=" + contactPassword + ", contactaddress=" + contactAddress
					+ ", getContactId()=" + getContactId() + ", getContactname()=" + getContactname()
					+ ", getEmailId()=" + getEmailId() + ", getPhone()=" + getPhone() + ", getContactpassword()="
					+ getContactpassword() + ", getContactaddress()=" + getContactaddress() + ", getClass()="
					+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
		}

		public Contact(Integer contactId,
				@NotEmpty @Size(min = 3, message = "firstName must contain atleast 3 characters") String contactname,
				@NotEmpty @Email(message = "Email  is not valid!") String emailId,
				@NotEmpty @Size(min = 10, max = 10, message = "phoneNumber must contain 10 digits") String phone,
				@NotEmpty @Size(min = 8, message = "Password length must be 8 and contain uppercase, lowercase, digits") 
		        @Pattern(regexp = "(?.\\d) (?.[a-z]) (?.[A-Z]).{8,}") String contactpassword,
				@NotEmpty(message = "Address cannot be empty") String contactaddress) 
		{
			super();
			this.contactId = contactId;
			this.contactName = contactname;
			this.emailId = emailId;
			this.phone = phone;
			this.contactPassword = contactpassword;
			this.contactAddress = contactaddress;
		}

		public Contact() 
		{
			super();
			// TODO Auto-generated constructor stub
		}	
}
	
	
	