package contactManagementSystem.cmsProject.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import contactManagementSystem.cmsProject.Dao.ContactDao;
import contactManagementSystem.cmsProject.Entity.Contact;

@Service
public class ContactService 
{
	@Autowired
	ContactDao 	contactDao;
	
	//save data
		public Contact saveContact( Contact  contact)
		{
			return contactDao.save(contact);
		}
	
		//get data by id
		public Contact getContacts(Integer contactId) 
	    {
	        return contactDao.findById(contactId).orElseThrow();
	    }
		
		//get all data
		public List<Contact> getContacts()
		{
			List<Contact> contacts=new ArrayList<Contact>();
			contactDao.findAll().forEach(contacts::add);
			return contacts;
			
		}
		
		//update data by id
		 public Contact updateContact(Contact contact) 
		    {
			 contactDao.findById(contact.getContactId()).orElseThrow();
		        return contactDao.save(contact);
		    }    
		 
		//delete data by id
			public void deleteContact(Integer contactId) 
		    {
             contactDao.deleteById(contactId);
		    }
			
			// Search employee by name
		    public Contact getContactByName(String contactName) 
		    {
		        return contactDao.findByContactName(contactName)
		                .orElseThrow(() -> new RuntimeException("Contact not found with name: " + contactName));
		    }
		    

		    // Method to get employees sorted by name
		    public List<Contact> getContactsSortedByName() 
		    {
		    	return contactDao.findAll(Sort.by(Sort.Direction.ASC, "contactName"));
		    }
		    
		    // Method to handle login
		    public Contact login(String emailId, String contactPassword)
		    {
		        return contactDao.findByEmailIdAndContactPassword(emailId, contactPassword)
		                .orElseThrow(() -> new RuntimeException("Invalid email or password!"));
		    }
		   
}
