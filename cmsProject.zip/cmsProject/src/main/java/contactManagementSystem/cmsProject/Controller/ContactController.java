package contactManagementSystem.cmsProject.Controller;

	import java.util.List;

	import org.springframework.beans.factory.annotation.Autowired;
    import org.springframework.http.HttpStatus;
    import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.CrossOrigin;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RestController;

	import contactManagementSystem.cmsProject.DTO.LoginRequest;
	import contactManagementSystem.cmsProject.Entity.Contact;
	import contactManagementSystem.cmsProject.Service.ContactService;

	@RestController
	@CrossOrigin("http://localhost:4200")
	public class ContactController 
	{
		@Autowired
		ContactService contactService;
		
		@PostMapping("/save/contact")
		public Contact saveContact(@RequestBody Contact contact)
		{
			return contactService.saveContact(contact);
		}

		@GetMapping("/get/contact")
		public List<Contact> getContacts()
		{
			return contactService.getContacts();	
		}

		@GetMapping("/get/contact/{contactId}")
	    public Contact getContact(@PathVariable Integer contactId)
	    {
	        return contactService.getContacts(contactId);
	    }
		
		 @DeleteMapping("/delete/contact/{contactId}")
		    public void deleteContact(@PathVariable Integer contactId) 
		    {
		        contactService.deleteContact(contactId);
		    }
		 
		 @PutMapping("/update/contact")
		    public ResponseEntity<Contact> updateContact(@RequestBody Contact contact) 
		    {
			  Contact updatedContact = contactService.updateContact(contact);
		        if (updatedContact != null) 
		        {
		            return ResponseEntity.ok(updatedContact);
		        } 
		        else
		        {
		            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
		        }
		    }   
		    
		    // End point to get employee by name
	        @GetMapping("/name/{contactName}")
	        public ResponseEntity<Contact> getContactByName(@PathVariable String contactName)
	        {
	            Contact contact = contactService.getContactByName(contactName);
	            return ResponseEntity.ok(contact);
	        }
	        
	     // End point to get employees sorted by name
	        @GetMapping("/sorted-by-name")
	        public ResponseEntity<List<Contact>> getContactsSortedByName() 
	        {
	            List<Contact> sortedContacts = contactService.getContactsSortedByName();
	            return ResponseEntity.ok(sortedContacts);
	        }
	        
	        // End point for login
	        @PostMapping("/login")
	        public ResponseEntity<String> login(@RequestBody LoginRequest loginRequest)
	        {
	            try 
	            {
	            	Contact contact = contactService.login(loginRequest.getEmailId(), loginRequest.getContactPassword());
	                 return ResponseEntity.ok("Welcome, " + contact.getContactname() + "!");
	            } 
	            catch (RuntimeException e) 
	            {
	                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(e.getMessage());
	            }
	        }
	
	}
	
