package contactManagementSystem.cmsProject.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import contactManagementSystem.cmsProject.Entity.Contact;


	@Repository
	public interface ContactDao extends JpaRepository<Contact, Integer>
	{
		//Method to find contact by email and password
		Optional<Contact> findByEmailIdAndContactPassword(String emailId, String contactPassword);

	// 1st	Optional<Contact> findByEmailIdAndContactPassword(String emailId, Object contactPassword);
		Optional<Contact> findByEmailId(String emailId);
	   // Method to find contact by name
		Optional<Contact> findByContactName(String contactName);
	  // Method to find all employees and sort by name
	    List<Contact> findAll(Sort sort);
		Optional<Contact> findById(Integer contactId);

}
